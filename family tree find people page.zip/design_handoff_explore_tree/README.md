# Handoff: "Explore the family tree" module — Direction B (Sepia feature band)

## Overview
This is a redesign of the **"Explore the family tree" start-here module** on the *Find People* page of The Gonsalves Family genealogy site. It's the banner that invites visitors into the interactive Tree Viewer, and it sits directly **below the hero + search** at full content width.

Only this one module changes. The hero, search bar, browse cards, people spotlight, and footer are **unchanged** and are not part of this handoff.

**Direction B** reframes the banner as a cinematic **sepia feature band**: a full-bleed archival photograph, darkened left-to-right so text stays legible, with cream type and a light "Open Tree Viewer" button. A faint family-tree glyph sits at the right.

## About the design files
The file in this bundle (`explore-tree-B.html`) is a **design reference created in HTML** — a prototype showing the intended look and behavior, **not production code to ship directly**. Recreate it inside the site's existing environment (React/Vue/Astro/Rails/etc.) using the project's established components, tokens, and conventions. If there is no front-end framework yet, the plain HTML/CSS here can be used as-is or ported to whatever the team adopts.

The CSS is written with vanilla custom properties and a single `.tv-band` block — map these to your design-token system and component primitives rather than copy-pasting class names wholesale.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and hover transitions are specified below to the pixel. Recreate it pixel-accurately using the codebase's existing libraries. The one placeholder is the **photograph** (see Assets).

## The module

### Name
`ExploreTreeBand` (start-here / tree-viewer CTA)

### Purpose
One tap into the interactive family Tree Viewer. It's the primary "I don't know where to start" entry point on the Find People page.

### Layout
- **Outer band**: `position: relative`, `display: flex`, `align-items: center`, `border-radius: 18px`, `overflow: hidden`, `min-height: 236px`, `border: 1px solid rgba(42,40,32,.18)`. Spans the page content column (max-width **1100px**), full width within it.
- **Layer stack (back → front):**
  1. `.photo` — absolute, `inset: 0`. The archival photograph (sepia-toned), `center / cover`.
  2. `.veil` — absolute, `inset: 0`. A horizontal darkening gradient for legibility.
  3. `.glyph` — absolute, right-aligned, vertically centered (decorative).
  4. `.inner` — the text block, `z-index: 2`, `max-width: 600px`, `padding: 34px 42px`.
- **Text block flow (top → bottom):** eyebrow → H2 → paragraph → button. Natural vertical flow, left-aligned.
- **Glyph**: absolute, `right: 38px`, `top: 50%`, `translateY(-50%)`, `180 × 108px`.

### Components / elements

| Element | Spec |
|---|---|
| **Eyebrow** ("Start here") | Hanken Grotesk, **11.5px**, weight **600**, `letter-spacing: .2em`, `text-transform: uppercase`, color **`#e8bca2`** (warm sepia-pink), `margin: 0 0 12px`. |
| **Heading** ("Explore the family tree") | Spectral, weight **500**, **34px**, `line-height: 1.04`, `letter-spacing: -.015em`, color **`#f7efdc`** (warm cream). Drops to **28px** at ≤760px. |
| **Paragraph** | Hanken Grotesk, **15px**, `line-height: 1.6`, color **`rgba(247,239,220,.82)`**, `margin: 9px 0 0`, `max-width: 46ch`. |
| **Button** ("Open Tree Viewer →") | Hanken Grotesk, **14.5px**, weight **600**. Padding **`14px 24px`**, `border-radius: 11px`, `margin-top: 22px`. Background **`#f4ecd8`**, text **`#244730`** (deep green). `display: inline-flex; align-items: center; gap: 9px`. Trailing arrow `→` in a `.arw` span. |
| **Photo veil** | `linear-gradient(90deg, rgba(34,24,11,.82), rgba(34,24,11,.40) 55%, rgba(34,24,11,.05))`. |
| **Glyph** | Inline SVG, `viewBox="0 0 200 120"`. 7 filled circles (radii 6/5/4) connected by `stroke-width: 1.6` lines at `opacity: .5`. Color `rgba(247,239,220,.5)`. Purely decorative (`aria-hidden`). |

### Exact copy (content)
- Eyebrow: **Start here**
- Heading: **Explore the family tree**
- Paragraph: **Six generations, one living map. Pan and zoom through every branch in the interactive Tree Viewer.**
- Button: **Open Tree Viewer →**

> The original site copy was "See how everyone connects — pan and zoom through generations in the interactive Tree Viewer." Either line works; the band version above is tighter for the overlay. Confirm with content owner.

## Interactions & behavior
- **Whole band is the click target into the Tree Viewer** is optional; the explicit **button** is the primary action — link it to the Tree Viewer route (`/tree` placeholder in the file).
- **Button hover:** background `#f4ecd8 → #fff`, `transform: translateY(-1px)`, and the arrow slides `translateX(3px)`. Transition `.18s` on `transform` and `background`.
- **Focus:** ensure a visible focus ring on the button (the prototype omits one — add per your a11y system).
- No loading/error/empty states — it's a static navigational CTA.
- **Reduced motion:** the hover transforms are tiny; gate them behind `@media (prefers-reduced-motion: no-preference)` if your system requires it.

### Responsive behavior
- **≤ 760px:** glyph hidden (`display: none`); `.inner` `max-width: none`, padding `28px 26px`; heading → 28px. Band keeps `min-height: 236px` (let it grow if copy wraps).
- The veil gradient already guarantees contrast at narrow widths because the dark side is on the left where text lives.
- Verify text contrast against the *actual* photo once dropped in — darken the veil's first stop toward `rgba(34,24,11,.9)` if a light photo reduces legibility.

## State management
None. Stateless presentational component. Only prop worth exposing: the **photo source** (and optional `href` for the button).

## Design tokens

**Colors**
| Token | Value | Use |
|---|---|---|
| Page cream (`--paper`) | `#eae3d1` | Background the band sits on |
| Band base | `#b6a484` | Fallback under the photo |
| Veil | `rgba(34,24,11,.82 → .40 → .05)` | Legibility gradient |
| Heading cream | `#f7efdc` | H2, glyph-ish lights |
| Body cream | `rgba(247,239,220,.82)` | Paragraph |
| Eyebrow | `#e8bca2` | Sepia-pink label |
| Button bg | `#f4ecd8` (hover `#fff`) | CTA |
| Button text / deep green (`--green-deep`) | `#244730` | CTA label |
| Green (`--green`) | `#2e5a3c` | Brand primary (elsewhere) |
| Oxblood (`--oxblood`) | `#974030` | Eyebrow labels elsewhere on page |
| Ink (`--ink`) | `#2a2820` | Default text elsewhere |

**Typography**
- Display / headings: **Spectral** (Google Fonts), weights 400/500/600 + italic 400.
- UI / body: **Hanken Grotesk** (Google Fonts), weights 400/500/600/700.

**Spacing used in this module:** 9, 12, 22, 24, 26, 34, 38, 42px.
**Radii:** band `18px`, button `11px`.
**Border:** `1px solid rgba(42,40,32,.18)` on the band.

## Assets
- **Archival photograph** — the only real asset to supply. Use a sepia/duotone family photo (e.g. the existing hero collage crop) at ≥ 1600px wide, `object-fit: cover`. The prototype fakes it with gradients; replace `.photo`'s `background` with `url(...) center/cover`. If the source photo isn't already toned, keep the `linear-gradient(135deg, rgba(120,96,58,.28), rgba(60,44,22,.42))` multiply layer over it for the sepia wash.
- **Tree glyph** — inline SVG, included in the file; no external asset. Optional: replace with a faint, blurred screenshot of the real Tree Viewer for extra context.
- **Fonts** — Spectral + Hanken Grotesk via Google Fonts (or self-host to match the rest of the site).
- **Icons** — none beyond the inline arrow character.

## Files in this bundle
- `explore-tree-B.html` — self-contained, pixel-accurate reference of Direction B (open in a browser to inspect).

### Related files in the source project (for context, not bundled)
- `Explore Tree - Redesigns.html` — the canvas showing all six explored directions (A–F); B is the second board.
- `tree-section.css` — the `.tv2` rule set is the production-leaning source for this module.
- `find-people.css` — the full brand token set + the rest of the Find People page (hero/search/footer/spotlight), if you need surrounding context.
- `Find People.html` — the three full-page discovery-zone directions, for how this module relates to the rest of the page.
